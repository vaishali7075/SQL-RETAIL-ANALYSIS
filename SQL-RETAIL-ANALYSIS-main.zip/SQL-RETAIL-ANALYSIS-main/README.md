# SQL-RETAIL-ANALYSIS
<H1>RETAIL ANALYSIS SQL PROJECT </H1>
<H3>DESCRIPTION</H3>
<H4>This project E-Commerce app that is continuously working on optimizing the app. This project involves analysing the orders to analyse daily trends and conversion rate and analyse user base growth . The goal is to understand the app performance .To generate the required and compile comprehensive report using SQL . The analysis is conducted using SQL to aggregate and join data from different tables representing each e-commerce date .</H4>
<H3>ANALYSIS POINT</H3>
<H4>1.The number of logins on a daily basis.<BR>
2.Daily trend of logins .<BR>
3.Which KPIs would you use to measure the performance of our app?<BR>
4. Prepare a report regarding our growth between the 2 years. Please try to answer the
following questions:<BR>
a. Did our business grow?<BR>
b. Does our app perform better now?<BR>
c. Did our user base grow?<BR>
5. What are our top-selling products in each of the two years? Can you draw some insight
from this?<BR>
6. Looking at July 2021 data, what do you think is our biggest problem and how would you
recommend fixing it?<BR>
</H4>
<H2>CONCLUSION </H2>
<H4>This analysis provide a detailed and insightful report that captures the necessary information and provide actionable insight for the e-commerce app optimization . We ware able to effectively aggregate and compare the data . The finding a top selling product id in each year and KPI(key performance indicator ) , performance of the e-commerce app . 
</H4>
